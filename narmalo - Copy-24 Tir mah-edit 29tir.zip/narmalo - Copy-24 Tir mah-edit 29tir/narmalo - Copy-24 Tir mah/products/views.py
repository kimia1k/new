from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, Cart, CartItem
from django.contrib.auth.decorators import login_required

def pelushi_dolls_view(request):
    products = Product.objects.filter(category='pelushi_dolls')
    return render(request, 'products/pelushi_dolls.html', {'products': products})

def baftani_dolls(request):
    return render(request, 'products/baftani_dolls.html')

def se_d_dolls(request):
    return render(request, 'products/se_d_dolls.html')

def custom_dolls(request):
    return render(request, 'products/custom_dolls.html')

def doll_clothes(request):
    return render(request, 'products/doll_clothes.html')


@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart, created = Cart.objects.get_or_create(user=request.user, defaults={'user': request.user})
    cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product, defaults={'cart': cart, 'product': product})
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    return redirect('cart_detail')

@login_required
def cart_detail(request):
    cart = get_object_or_404(Cart, user=request.user)
    cart_items = CartItem.objects.filter(cart=cart)
    total_price = sum(item.get_total_price() for item in cart_items)
    return render(request, 'products/cart_detail.html', {'cart_items': cart_items, 'total_price': total_price})

@login_required
def remove_from_cart(request, cart_item_id):
    cart_item = get_object_or_404(CartItem, id=cart_item_id, cart__user=request.user)
    cart_item.delete()
    return redirect('cart_detail')