from django.urls import path
from . import views

from .views import pelushi_dolls_view

urlpatterns = [
    path('', views.home_view, name='home'),
    path('about/', views.about_view, name='about'),
    path('contact/', views.contact_view, name='contact'),
    path('cart/', views.cart_view, name='cart'),
    path('products/', views.products_view, name='products'),
    path('products/<str:category>/', views.product_list, name='product_list'),
    path('profile/', views.profile, name='profile'),
    path('products/pelushi-dolls/', pelushi_dolls_view, name='pelushi_dolls'),
]

