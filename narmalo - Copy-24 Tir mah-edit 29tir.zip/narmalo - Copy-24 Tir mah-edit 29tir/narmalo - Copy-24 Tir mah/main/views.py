from django.shortcuts import render, redirect
from .models import Product,Profile, Wallet, Favorite
from django.contrib.auth.decorators import login_required
from .forms import UserForm, ProfileForm
from products.models import Product 

def home_view(request):
    return render(request, 'home.html')

def about_view(request):
    return render(request, 'about.html')

def contact_view(request):
    return render(request, 'contact.html')

def cart_view(request):
    return render(request, 'cart.html')

def products_view(request):
    return render(request, 'products.html')


def pelushi_dolls_view(request):
    products = Product.objects.filter(category='pelushi_dolls')
    return render(request, 'products/pelushi_dolls.html', {'products': products})
def product_list(request, category):
    templates = {
        'pelushi': 'products/pelushi_dolls.html',
        'baftani': 'products/templates/products/baftani_dolls.html',
        'se_d': 'products/templates/products/se_d_dolls.html',
        'custom': 'products/templates/products/custom_dolls.html',
        'clothes': 'products/templates/products/doll_clothes.html',
    }
    template = templates.get(category)
    if template is None:
        return render(request, 'home.html')
    products = Product.objects.filter(category=category)
    return render(request, template, {'products': products})


@login_required
def profile(request):
    if request.method == 'POST':
        user_form = UserForm(request.POST, instance=request.user)
        profile_form = ProfileForm(request.POST, request.FILES, instance=request.user.profile)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            return redirect('profile')
    else:
        user_form = UserForm(instance=request.user)
        profile_form = ProfileForm(instance=request.user.profile)
    
    print("Trying to render 'products/profile.html'")  # برای دیباگ

    return render(request, 'products/profile.html', {
        'user_form': user_form,
        'profile_form': profile_form
    })
    
    
def profile_view(request):
    user = request.user
    profile = Profile.objects.get(user=user)
    wallet = Wallet.objects.get(user=user)
    favorites = Favorite.objects.filter(user=user)

    if request.method == 'POST':
        user_form = UserForm(request.POST, instance=user)
        profile_form = ProfileForm(request.POST, instance=profile)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            return redirect('profile')  # نام URL مربوط به پروفایل را مشخص کنید
    else:
        user_form = UserForm(instance=user)
        profile_form = ProfileForm(instance=profile)

    context = {
        'user_form': user_form,
        'profile_form': profile_form,
        'wallet': wallet,
        'favorites': favorites,
    }
    return render(request, 'products/profile.html', context)


def pelushi_dolls_view(request):
    products = Product.objects.filter(category='pelushi_dolls')  # فیلتر محصولات بر اساس دسته‌بندی
    return render(request, 'products/pelushi_dolls.html', {'products': products})